//ScrollReveal().reveal('.menu'), {delay: 500};
//ScrollReveal().reveal('#carouselExampleCaptions'), {delay: 500};

//
ScrollReveal().reveal('body');
ScrollReveal().reveal('.cat-produc', {delay: 500});
ScrollReveal().reveal('.content-cat', {delay: 500});
ScrollReveal().reveal('.footer', {delay: 600});

ScrollReveal().reveal('.conten-infor-general', {delay: 500});
ScrollReveal().reveal('.content-inform', {delay: 500});
ScrollReveal().reveal('.ayuda', {delay: 500});
ScrollReveal().reveal('.content-integrants', {delay: 500});

