const formulario = document.getElementById('pago-Direccion');
const inputs = document.querySelectorAll('#pago-Direccion input');

const expresiones = {
    //direccion
    direccion: /^[a-zA-ZÀ-ÿ0-9\s\#]{1,50}$/, // Letras y espacios, pueden llevar acentos.
    numeroC:   /^[1-500\#]{1,7}$/, // 1 a 10 digitos.
    cedula: /^\d{10}$/, // 7 a 10 numeros.

    //pago
    tarjeta: /^.{10,20}$/, // 10 a 20 numeros.
    vencimiento: /^[0-9]+\/[20-40]{1,7}$/,
    seguridad: /^.{2,5}$/,
}

const campos = {
	direccion: false,
	numeroC: false,
	cedula: false,
	tarjeta: false,
    vencimiento: false,
    seguridad: false
}


const validarPago = (e) => {
	switch (e.target.name) {
		case "direccion":
			validarCampo(expresiones.direccion, e.target, 'direccion');
		break;
		case "numeroC":
			validarCampo(expresiones.numeroC, e.target, 'numeroC');
		break;

		case "cedula":
			validarCampo(expresiones.cedula, e.target, 'cedula');
		break;
		case "tarjeta":
            validarCampo(expresiones.tarjeta, e.target, 'tarjeta');
		break;
		case "vencimiento":
			validarCampo(expresiones.vencimiento, e.target, 'vencimiento');
		break;
		case "seguridad":
			validarCampo(expresiones.seguridad, e.target, 'seguridad');
		break;
	}
}

const validarCampo = (expresion, input, campo) => {
	if(expresion.test(input.value)){
		document.getElementById(`grupo__${campo}`).classList.remove('formulario__grupo-incorrecto');
		document.getElementById(`grupo__${campo}`).classList.add('formulario__grupo-correcto');
		document.querySelector(`#grupo__${campo} i`).classList.add('fa-check-circle');
		document.querySelector(`#grupo__${campo} i`).classList.remove('fa-times-circle');
		document.querySelector(`#grupo__${campo} .formulario__input-error`).classList.remove('formulario__input-error-activo');
		campos[campo] = true;
	} else {
		document.getElementById(`grupo__${campo}`).classList.add('formulario__grupo-incorrecto');
		document.getElementById(`grupo__${campo}`).classList.remove('formulario__grupo-correcto');
		document.querySelector(`#grupo__${campo} i`).classList.add('fa-times-circle');
		document.querySelector(`#grupo__${campo} i`).classList.remove('fa-check-circle');
		document.querySelector(`#grupo__${campo} .formulario__input-error`).classList.add('formulario__input-error-activo');
		campos[campo] = false;
	}
}

inputs.forEach((input) => {
	input.addEventListener('keyup', validarPago);
	input.addEventListener('blur', validarPago);
});

formulario.addEventListener('submit', (e) => {
	e.preventDefault();

	if(campos.direccion && campos.numeroC && campos.cedula && campos.tarjeta && campos.vencimiento && campos.seguridad){
		Swal.fire({
            type: 'exito',
            title: 'Compra realizada',
            text: 'A continiacion se presenta los detalles',
            showConfirmButton: false,
            timer: 9000
		})

		formulario.reset();
        location.href ="confirmacion.html";
		document.querySelectorAll('.formulario__grupo-correcto').forEach((icono) => {
			icono.classList.remove('formulario__grupo-correcto');
		});

	} else {
        Swal.fire({
            type: 'error',
            title: 'Oops...',
            text: 'Completar todos los campos',
            showConfirmButton: true,
            timer: 5000
        })
		
	}
});