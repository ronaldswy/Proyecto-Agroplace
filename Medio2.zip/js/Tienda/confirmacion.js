const confirmacion = new Carrito();
const listaConfirmacion = document.querySelector("#lista-cnfirmacion tbody" );

cargarEventos();

function cargarEventos(){

    document.addEventListener('DOMContentLoaded', confirmacion. leerLocalStorageConfirmacion());
    confirmacion.calcularTotal();
}