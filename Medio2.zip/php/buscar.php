<?php
    mysqli =new mysqli("localhost","root","","producto");
    $salida ="";
    $query = "SELECT * FROM tbl_productos ORDER By Nombre";
    if(isset($_POST['consulta'])){
        $q = $mysqli->real_escape_string($_POST['consulta']);
        $query ="SELECT Nombre, SKU, Precio, Categoria FROM tbl_productos WHERE Nombre LIKE '%",$q,"%'";
        $resultado = $mysqli->$query($query);
        
    } 
?>