<?php
include("con_db.php") or die ("<h2>Error en la conexion</h2>");

if($conex){
    echo "todo bien";
}

if (isset($_POST['Aceptar'])) {

    if (strlen($_POST['usuario']) >= 1 && strlen($_POST['nombre']) >= 1 && strlen($_POST['password']) >= 1 && 
        strlen($_POST['password2']) >= 1 && strlen($_POST['correo']) >= 1 && strlen($_POST['telefono']) >= 1){

            $usuario = trim($_POST['usuario']);
            $nombre = trim($_POST['nombre']) ;
            $password = trim($_POST['password']); 
            $password2 = trim($_POST['password2']);
            $correo = trim($_POST['correo']);
            $telefono = trim($_POST['telefono']);
            $consulta = "INSERT INTO datos_cliente(Usuario, Nombres, Telefono, Correo, Contraseña, R_contraseña,) VALUES ('$usuario','$nombre','$password','$password2','$correo','$telefono')";
            $resultado = mysqli_query($conex,$consulta);
            
            if($resultado){

                ?><h3 class="ok" >Te has registrado correctamente </h3>
                <
                <?php
            } else {
                ?>
                <h3 class="bad"> Ups ha ocurrido algun error</h3>
                <?php
            }
    }else{
        ?>
        <h3 class="bad"> Por favor completo los campos</h3>
        <?php
    }
}
?>