<?php
$conex = mysqli_connect("localhost","root","","php_login_database") or die ("<h2>Error en la conexion</h2>");;
?>