<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" href="css/Carrito/bootstrap.min.css">
    <link rel="stylesheet" href="css/Carrito/sweetalert2.min.css">
    <link rel="stylesheet" href="https://necolas.github.io/normalize.css/8.0.1/normalize.css">

    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200;300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/estilos.css">
    <link rel="stylesheet" type="text/css" href="css/registro.css">
    <title>AgroPlace</title>

</head>

<body>
    <!--<div class="container">-->
    <script>
        function abrir() {
            document.getElementById("content-carrito-agre").style.display = "block";
        }
        function cerrar() {
            document.getElementById("content-carrito-agre").style.display = "none";
        }


    </script>
    <!--<div class="container">-->
    <div class="menu">

        <div class="logo"><img src="img/AGROPLACE.svg" alt="parcelastock-Logo" class="nav-brand"></div>

        <div class="nav-main">
            <nav>
                <ul class="nav-menu">
                    <li>
                        <a style="text-decoration: none;" href="index.html">Inicio</a>
                    </li>
                    <li>
                        <a style="text-decoration: none;" href="productos.html">Productos</a>
                    </li>
                    <li>
                        <a style="text-decoration: none;" href="contactos.html">Contactos</a>
                    </li>
                    <li>
                        <a style="text-decoration: none;" href="nosotros.html">Sobre Nosotros</a>
                    </li>
                </ul>
            </nav>
        </div>

        <div class="btn-nav">
            <ul class="nav-menu-right">
                <li>
                    <a style="text-decoration: none;" href="registro.html" class="btn-registro"> Regístrate </a>
                </li>
                <li>
                    <a style="text-decoration: none;" href="login.html" class="btn-iniciar-sesion"> Iniciar Sesión</a>
                </li>
            </ul>
        </div>

    </div>

    <main>

        <div class="name-register">
            <h4>Regístro</h4>
        </div>

        <form action="PHPregistro.php"  method="POST" class="formulario" id="formulario">
            <!-- Grupo: Usuario -->
            <div class="formulario__grupo" id="grupo__usuario">
                <label for="usuario" class="formulario__label">Usuario</label>
                <div class="formulario__grupo-input">
                    <input type="text" class="formulario__input" name="usuario" id="usuario" placeholder="john123">
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El usuario tiene que ser de 4 a 40 dígitos y solo puede contener
                    numeros, letras y guion bajo.</p>
            </div>

            <!-- Grupo: Nombre -->
            <div class="formulario__grupo" id="grupo__nombre">
                <label for="nombre" class="formulario__label">Nombre</label>
                <div class="formulario__grupo-input">
                    <input type="text" class="formulario__input" name="nombre" id="nombre" placeholder="John Doe">
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El usuario tiene que ser de 4 a 16 dígitos y solo puede contener
                    numeros, letras y guion bajo.</p>
            </div>

            <!-- Grupo: Contraseña -->
            <div class="formulario__grupo" id="grupo__password">
                <label for="password" class="formulario__label">Contraseña</label>
                <div class="formulario__grupo-input">
                    <input type="password" class="formulario__input" name="password" id="password">
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">La contraseña tiene que ser de 4 a 12 dígitos.</p>
            </div>

            <!-- Grupo: Contraseña 2 -->
            <div class="formulario__grupo" id="grupo__password2">
                <label for="password2" class="formulario__label">Repetir Contraseña</label>
                <div class="formulario__grupo-input">
                    <input type="password" class="formulario__input" name="password2" id="password2">
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">Ambas contraseñas deben ser iguales.</p>
            </div>

            <!-- Grupo: Correo Electronico -->
            <div class="formulario__grupo" id="grupo__correo">
                <label for="correo" class="formulario__label">Correo Electrónico</label>
                <div class="formulario__grupo-input">
                    <input type="email" class="formulario__input" name="correo" id="correo"
                        placeholder="correo@correo.com">
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El correo solo puede contener letras, numeros, puntos, guiones y
                    guion bajo.</p>
            </div>

            <!-- Grupo: Teléfono -->
            <div class="formulario__grupo" id="grupo__telefono">
                <label for="telefono" class="formulario__label">Teléfono</label>
                <div class="formulario__grupo-input">
                    <input type="text" class="formulario__input" name="telefono" id="telefono" placeholder="4491234567">
                    <i class="formulario__validacion-estado fas fa-times-circle"></i>
                </div>
                <p class="formulario__input-error">El telefono solo puede contener numeros y el maximo son 14 dígitos.
                </p>
            </div>

            <!-- Grupo: Terminos y Condiciones -->
            <div class="formulario__grupo" id="grupo__terminos">
                <label class="formulario__label">
                    <input class="formulario__checkbox" type="checkbox" name="terminos" id="termino">
                    Acepto los Terminos y Condiciones
                </label>
            </div>

            <div class="formulario__mensaje" id="formulario__mensaje">
                <p><i class="fas fa-exclamation-triangle"></i> <b>Error:</b> Por favor rellena el formulario
                    correctamente. </p>
            </div>

            <div class="formulario__grupo formulario__grupo-btn-enviar">
                <input class="formulario__btn" type="submit" onclick=go() name="aceptar"></input>
                <p class="formulario__mensaje-exito" id="formulario__mensaje-exito">Formulario enviado exitosamente!</p>
            </div>
        </form>
    </main>

    <?php
    include("PHPregistro.php");
    ?>
    
    <script src="js/formulario.js"></script>
    <script src="https://kit.fontawesome.com/2c36e9b7b1.js" crossorigin="anonymous"></script>

    <!--Pie de página-->

    <footer class="footer">
        <section class="section-footer">

            <section class="informacion">
                <div class="servicio">
                    <h4> SERVICIOS</h4>

                    <p>AgroPlace es una tienda online que ofrece a los agricultores una gama amplia de químicos
                        necesarios para sus porductos</p>
                </div>
                <div class="redes">
                    <h4> Seguenos en redes Sociales</h4>
                    <a href="#"> <img src="img/iconos/facebook.svg" alt="facebook" width="32px" height="32px"></a>
                    <a href="#"><img src="img/iconos/instagram.svg" alt="instagram" width="32px" height="32px"></a>
                </div>
            </section>

            <div class="footer-menu">
                <h4> MENU </h4>
                <nav>
                    <ul class="nav-menu">
                        <li>
                            <a style="text-decoration: none;" href="index.html">Inicio</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="productos.html">Productos</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="contactos.html">Contactos</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="nosotros.html">Sobre Nosotros</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="footer-catalogo">
                <h4> CATÁLOGOS </h4>
                <nav>
                    <ul class="nav-menu">
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/insecticidas.html">Insecticidas</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/herbicidas.html">Herbicidas</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/fungicidas.html">Fungicidas</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/fertilizantes.html">Fertilizantes</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/raticidas.html">Racticidas</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/humectantes.html">Humectantes</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/aspesoras.html"> Aspesoras</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Catalogos/agroVarios.html">AgroVarios</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="footer-cuenta">
                <h4> MI CUENTA </h4>
                <nav>
                    <ul class="nav-menu">
                        <li>
                            <a style="text-decoration: none;" href="Cuenta/Pedidos.html"> Mis pedidos</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Cuenta/direcciones.html"> Mis direcciones</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Cuenta/billetera.html"> Mi billetera</a>
                        </li>
                        <li>
                            <a style="text-decoration: none;" href="Cuenta/cuenta.html"> Mi cuenta</a>
                        </li>
                    </ul>
                </nav>

            </div>
            <div class="footer-cantactos">
                <h4> CONCTATOS </h4>
                <p>0964572347</p>
                <p>agroplace@gmail.com</p>
            </div>
        </section>
    </footer>

<!--SCROLL REVEAL-->
<script src="https://unpkg.com/scrollreveal"></script>
<!--CUSTOM JS-->
<script src="/js/main.js"></script>

</body>

</html>