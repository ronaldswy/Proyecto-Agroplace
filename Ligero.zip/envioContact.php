<?php

//llamamdo a los campos
$nombre = $_POST['c-nombre'];
$correo = $_POST['c-correo'];
$telefono = $_POST['c-telefono'];
$mensaje = $_POST['c-mensaje'];

$destino = "jonatcraft@gmail.com";
$asunto = "Contacto desde nuestra web";

$msg = "De: $nombre \n";
$msg .= "Correo: $correo \n";
$msg .= "Telefono: $telefono \n";
$msg .= "Mensaje: $mensaje";

//Eviar mensaje
mail($destino, $asunto, $msg);
header('Location:msgEnviado.html');
?>